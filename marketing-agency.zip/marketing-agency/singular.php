<?php
/**
 * The template for displaying all singular posts, pages, and CPTs
 * Calls the_content() directly for complete Elementor visual editor compatibility
 *
 * @package MarketingAgency
 */

get_header();
?>

<div id="content" class="site-content">
    <?php
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
    ?>
</div>

<?php
get_footer();
