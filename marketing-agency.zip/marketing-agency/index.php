<?php
/**
 * Main Template File for Marketing Agency
 *
 * @package MarketingAgency
 */

get_header();
?>

<div id="content" class="site-content">
    <?php
    if (have_posts()) :
        while (have_posts()) :
            the_post();
            the_content();
        endwhile;
    endif;
    ?>
</div>

<?php
get_footer();
