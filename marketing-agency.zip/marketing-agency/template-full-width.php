<?php
/**
 * Template Name: Elementor Full Width
 * Template Post Type: post, page, services, portfolio
 *
 * @package MarketingAgency
 */

get_header();
?>

<div id="content" class="site-content de-full-width-content">
    <?php
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
    ?>
</div>

<?php
get_footer();
