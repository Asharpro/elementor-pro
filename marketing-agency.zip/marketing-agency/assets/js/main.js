/**
 * DIGITAL EXPERTS — INTERACTIVE SCRIPTS & ANIMATIONS
 * Modern, responsive interactions matching the reference agency UX.
 * Integrates GSAP, ScrollTrigger, and resilient native fallbacks.
 */

(function () {
  'use strict';

  // 1. STICKY HEADER & SCROLL BEHAVIOR
  const header = document.querySelector('.de-header-wrapper');
  function handleScroll() {
    if (!header) return;
    if (window.scrollY > 40) {
      header.classList.add('is-scrolled');
    } else {
      header.classList.remove('is-scrolled');
    }
  }
  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();

  // 2. MOBILE DRAWER NAVIGATION
  const mobileToggle = document.querySelector('.de-mobile-toggle');
  const mobileDrawer = document.querySelector('.de-mobile-drawer');
  const mobileOverlay = document.querySelector('.de-mobile-overlay');
  const mobileClose = document.querySelector('.de-mobile-close');

  function openMobileMenu() {
    if (mobileDrawer) mobileDrawer.classList.add('is-active');
    if (mobileOverlay) mobileOverlay.classList.add('is-active');
    document.body.style.overflow = 'hidden';
  }

  function closeMobileMenu() {
    if (mobileDrawer) mobileDrawer.classList.remove('is-active');
    if (mobileOverlay) mobileOverlay.classList.remove('is-active');
    document.body.style.overflow = '';
  }

  if (mobileToggle) mobileToggle.addEventListener('click', openMobileMenu);
  if (mobileClose) mobileClose.addEventListener('click', closeMobileMenu);
  if (mobileOverlay) mobileOverlay.addEventListener('click', closeMobileMenu);

  // Mobile Submenu Accordions
  const dropdownBtns = document.querySelectorAll('.de-mobile-dropdown-btn');
  dropdownBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const targetMenu = document.getElementById(targetId);
      if (targetMenu) {
        targetMenu.classList.toggle('is-open');
      }
    });
  });

  // 3. FAQ ACCORDION INTERACTION
  const faqItems = document.querySelectorAll('.de-faq-item');
  faqItems.forEach(item => {
    const trigger = item.querySelector('.de-faq-trigger');
    const content = item.querySelector('.de-faq-content');

    if (trigger && content) {
      trigger.addEventListener('click', () => {
        const isOpen = item.classList.contains('is-open');

        // Close other FAQs in the same group
        faqItems.forEach(otherItem => {
          if (otherItem !== item) {
            otherItem.classList.remove('is-open');
            const otherContent = otherItem.querySelector('.de-faq-content');
            if (otherContent) otherContent.style.maxHeight = null;
          }
        });

        // Toggle current
        if (isOpen) {
          item.classList.remove('is-open');
          content.style.maxHeight = null;
        } else {
          item.classList.add('is-open');
          content.style.maxHeight = content.scrollHeight + 'px';
        }
      });
    }
  });

  // 4. CONTINUOUS MARQUEE DUPLICATION
  const marqueeTrack = document.querySelector('.de-marquee-track');
  if (marqueeTrack) {
    // Clone children to ensure perfectly smooth endless scrolling loop
    const children = Array.from(marqueeTrack.children);
    children.forEach(child => {
      const clone = child.cloneNode(true);
      clone.setAttribute('aria-hidden', 'true');
      marqueeTrack.appendChild(clone);
    });
  }

  // 5. PROCESS STEP TIMELINE HOVER INTERACTION
  const processSteps = document.querySelectorAll('.de-process-step');
  processSteps.forEach(step => {
    step.addEventListener('mouseenter', () => {
      processSteps.forEach(s => s.classList.remove('is-active'));
      step.classList.add('is-active');
    });
  });

  // 6. CONSULTATION MODAL TRIGGER & CLOSE
  const consultationTriggers = document.querySelectorAll('[data-open-consultation]');
  const consultationModal = document.getElementById('consultationModal');
  const modalClose = document.querySelector('.de-modal-close');

  function openConsultationModal(e) {
    if (e) e.preventDefault();
    if (consultationModal) {
      consultationModal.classList.add('is-active');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeConsultationModal() {
    if (consultationModal) {
      consultationModal.classList.remove('is-active');
      document.body.style.overflow = '';
    }
  }

  consultationTriggers.forEach(t => t.addEventListener('click', openConsultationModal));
  if (modalClose) modalClose.addEventListener('click', closeConsultationModal);
  if (consultationModal) {
    consultationModal.addEventListener('click', (e) => {
      if (e.target === consultationModal) closeConsultationModal();
    });
  }

  // 7. FORM SUBMISSION VALIDATION & USER FEEDBACK
  const forms = document.querySelectorAll('.de-consultation-form, .de-newsletter-form');
  forms.forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const submitBtn = form.querySelector('button[type="submit"]');
      const originalText = submitBtn ? submitBtn.innerHTML : 'Submit';
      const statusBox = form.querySelector('.de-form-status');

      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = 'Sending Consultation Request...';
      }

      // Simulate API submission
      setTimeout(() => {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = 'Success!';
        }
        if (statusBox) {
          statusBox.classList.add('is-success');
          statusBox.innerHTML = 'Thank you! Your request has been received. A Digital Experts specialist will contact you within 24 hours with your customized growth roadmap.';
        }
        form.reset();

        setTimeout(() => {
          if (submitBtn) submitBtn.innerHTML = originalText;
        }, 5000);
      }, 1000);
    });
  });

  // 8. INTERSECTION OBSERVER & GSAP SCROLL REVEALS
  function initScrollAnimations() {
    const fadeElements = document.querySelectorAll('.de-fade-in');

    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver((entries, obs) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            obs.unobserve(entry.target);
          }
        });
      }, {
        threshold: 0.12,
        rootMargin: '0px 0px -40px 0px'
      });

      fadeElements.forEach(el => observer.observe(el));
    } else {
      fadeElements.forEach(el => el.classList.add('is-visible'));
    }

    // GSAP ScrollTrigger enhancement if library loaded
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
      gsap.registerPlugin(ScrollTrigger);

      // Hero animation sequence
      gsap.from('.de-hero-headline', {
        y: 40,
        opacity: 0,
        duration: 0.9,
        ease: 'power3.out'
      });

      gsap.from('.de-hero-paragraph', {
        y: 30,
        opacity: 0,
        duration: 0.8,
        delay: 0.2,
        ease: 'power3.out'
      });

      gsap.from('.de-hero-actions', {
        y: 20,
        opacity: 0,
        duration: 0.8,
        delay: 0.35,
        ease: 'power3.out'
      });

      gsap.from('.de-hero-visual', {
        scale: 0.95,
        opacity: 0,
        duration: 1,
        delay: 0.2,
        ease: 'power2.out'
      });

      // Card Stagger on Pillars
      gsap.from('.de-pillar-card', {
        scrollTrigger: {
          trigger: '.de-pillars-grid',
          start: 'top 80%',
        },
        y: 45,
        opacity: 0,
        stagger: 0.18,
        duration: 0.85,
        ease: 'power2.out'
      });

      // Process step stagger
      gsap.from('.de-process-step', {
        scrollTrigger: {
          trigger: '.de-process-timeline',
          start: 'top 80%',
        },
        y: 30,
        opacity: 0,
        stagger: 0.15,
        duration: 0.7,
        ease: 'power2.out'
      });
    }
  }

  // Run when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initScrollAnimations);
  } else {
    initScrollAnimations();
  }

})();
