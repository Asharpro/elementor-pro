<?php
/**
 * The template for displaying all pages in Marketing Agency
 * Fully compatible with Elementor visual builder
 *
 * @package MarketingAgency
 */

get_header();
?>

<div id="content" class="site-content">
    <?php
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
    ?>
</div>

<?php
get_footer();
