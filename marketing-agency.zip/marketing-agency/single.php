<?php
/**
 * The template for displaying all single posts
 * Fully compatible with Elementor
 *
 * @package MarketingAgency
 */

get_header();
?>

<div id="content" class="site-content">
    <?php
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
    ?>
</div>

<?php
get_footer();
