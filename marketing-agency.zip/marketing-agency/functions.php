<?php
/**
 * Marketing Agency Theme Functions & Setup
 * Built specifically for Elementor Pro & Hello Elementor
 *
 * @package MarketingAgency
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('MARKETING_AGENCY_VERSION', '1.0.0');

/**
 * Enqueue Theme Scripts and Styles
 */
function marketing_agency_scripts() {
    // 1. Parent theme style (Hello Elementor) if active
    if (wp_get_theme()->parent()) {
        wp_enqueue_style('hello-elementor-parent', get_template_directory_uri() . '/style.css');
    }

    // 2. Google Fonts: Manrope, Plus Jakarta Sans, Inter
    wp_enqueue_style(
        'marketing-agency-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Manrope:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap',
        array(),
        null
    );

    // 3. Main Agency Stylesheet
    wp_enqueue_style(
        'marketing-agency-core-style',
        get_stylesheet_directory_uri() . '/assets/css/style.css',
        array(),
        MARKETING_AGENCY_VERSION
    );

    // 4. GSAP 3.12.5 & ScrollTrigger
    wp_enqueue_script(
        'gsap',
        'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js',
        array(),
        '3.12.5',
        true
    );

    wp_enqueue_script(
        'gsap-scroll-trigger',
        'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js',
        array('gsap'),
        '3.12.5',
        true
    );

    // 5. Agency Interactive Script
    wp_enqueue_script(
        'marketing-agency-main',
        get_stylesheet_directory_uri() . '/assets/js/main.js',
        array('jquery', 'gsap', 'gsap-scroll-trigger'),
        MARKETING_AGENCY_VERSION,
        true
    );

    // Localize for AJAX consultation requests
    wp_localize_script('marketing-agency-main', 'maAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('ma_consultation_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'marketing_agency_scripts', 20);

/**
 * Theme Setup & Elementor Compatibility
 */
function marketing_agency_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 80,
        'width'       => 260,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    add_theme_support('align-wide');
    add_theme_support('responsive-embeds');

    // Register Navigation Menus
    register_nav_menus(array(
        'primary-menu'   => __('Primary Header Menu', 'marketing-agency'),
        'mega-marketing' => __('Services: Digital Marketing', 'marketing-agency'),
        'mega-design'    => __('Services: Design', 'marketing-agency'),
        'mega-dev'       => __('Services: Development', 'marketing-agency'),
        'mega-media'     => __('Services: Media Production', 'marketing-agency'),
        'footer-quick'   => __('Footer Quick Links', 'marketing-agency')
    ));
}
add_action('after_setup_theme', 'marketing_agency_setup');

/**
 * Register Custom Post Types for Portfolio, Services, Testimonials
 */
function marketing_agency_register_post_types() {
    // 1. Portfolio Projects
    register_post_type('portfolio', array(
        'labels' => array(
            'name'          => __('Portfolio Projects', 'marketing-agency'),
            'singular_name' => __('Portfolio Project', 'marketing-agency'),
            'add_new_item'  => __('Add New Project', 'marketing-agency'),
            'all_items'     => __('All Projects', 'marketing-agency')
        ),
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => array('slug' => 'portfolio'),
        'supports'     => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'elementor'),
        'menu_icon'    => 'dashicons-portfolio',
        'show_in_rest' => true
    ));

    register_taxonomy('portfolio_category', 'portfolio', array(
        'labels' => array(
            'name'          => __('Project Categories', 'marketing-agency'),
            'singular_name' => __('Project Category', 'marketing-agency')
        ),
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true
    ));

    // 2. Services
    register_post_type('services', array(
        'labels' => array(
            'name'          => __('Services', 'marketing-agency'),
            'singular_name' => __('Service', 'marketing-agency'),
            'add_new_item'  => __('Add New Service', 'marketing-agency'),
            'all_items'     => __('All Services', 'marketing-agency')
        ),
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => array('slug' => 'service'),
        'supports'     => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'elementor'),
        'menu_icon'    => 'dashicons-networking',
        'show_in_rest' => true
    ));

    register_taxonomy('service_category', 'services', array(
        'labels' => array(
            'name'          => __('Service Categories', 'marketing-agency'),
            'singular_name' => __('Service Category', 'marketing-agency')
        ),
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true
    ));

    // 3. Testimonials
    register_post_type('testimonials', array(
        'labels' => array(
            'name'          => __('Testimonials', 'marketing-agency'),
            'singular_name' => __('Testimonial', 'marketing-agency')
        ),
        'public'       => false,
        'show_ui'      => true,
        'supports'     => array('title', 'editor', 'thumbnail', 'custom-fields'),
        'menu_icon'    => 'dashicons-testimonial',
        'show_in_rest' => true
    ));
}
add_action('init', 'marketing_agency_register_post_types');

/**
 * Register Elementor Theme Builder Locations
 */
function marketing_agency_register_elementor_locations($elementor_theme_manager) {
    $elementor_theme_manager->register_location('header');
    $elementor_theme_manager->register_location('footer');
    $elementor_theme_manager->register_location('single');
    $elementor_theme_manager->register_location('archive');
}
add_action('elementor/theme/register_locations', 'marketing_agency_register_elementor_locations');

/**
 * Elementor Settings Initialization (Containers & Post Types)
 */
function marketing_agency_elementor_init() {
    $cpts = get_option('elementor_cpt_support', array('post', 'page'));
    $custom = array('portfolio', 'services');
    foreach ($custom as $cpt) {
        if (!in_array($cpt, $cpts)) {
            $cpts[] = $cpt;
        }
    }
    update_option('elementor_cpt_support', $cpts);
    update_option('elementor_experiment-container', 'active');
}
add_action('after_switch_theme', 'marketing_agency_elementor_init');

/**
 * Enable SVG Uploads in Media Library
 */
function marketing_agency_mime_types($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    $mimes['svgz'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'marketing_agency_mime_types');

/**
 * AJAX Consultation Form Endpoint
 */
function marketing_agency_handle_consultation() {
    check_ajax_referer('ma_consultation_nonce', 'nonce');

    $first_name = sanitize_text_field($_POST['first_name'] ?? '');
    $last_name  = sanitize_text_field($_POST['last_name'] ?? '');
    $email      = sanitize_email($_POST['email'] ?? '');
    $phone      = sanitize_text_field($_POST['phone'] ?? '');
    $company    = sanitize_text_field($_POST['company'] ?? '');
    $service    = sanitize_text_field($_POST['service'] ?? '');
    $message    = sanitize_textarea_field($_POST['message'] ?? '');

    if (empty($email) || empty($first_name)) {
        wp_send_json_error(array('message' => 'Please provide your name and work email.'));
    }

    $admin_email = get_option('admin_email');
    $subject = sprintf('[Marketing Agency] Consultation Request from %s %s', $first_name, $last_name);
    $body = "New Growth Consultation Request:\n\n"
          . "Name: $first_name $last_name\n"
          . "Email: $email\n"
          . "Phone: $phone\n"
          . "Company: $company\n"
          . "Service Required: $service\n"
          . "Scope & Goals:\n$message\n\n"
          . "Submitted: " . current_time('mysql');

    $headers = array('Content-Type: text/plain; charset=UTF-8', "Reply-To: $first_name $last_name <$email>");

    @wp_mail($admin_email, $subject, $body, $headers);

    wp_send_json_success(array('message' => 'Consultation inquiry received successfully.'));
}
add_action('wp_ajax_ma_consultation', 'marketing_agency_handle_consultation');
add_action('wp_ajax_nopriv_ma_consultation', 'marketing_agency_handle_consultation');
