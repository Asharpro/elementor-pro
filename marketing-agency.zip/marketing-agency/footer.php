<?php
/**
 * Footer template for Marketing Agency
 * Compatible with Elementor Theme Builder
 */
if (!defined('ABSPATH')) {
    exit;
}
?>
</main><!-- #primary -->

<?php
if (!function_exists('elementor_theme_do_location') || !elementor_theme_do_location('footer')) {
    ?>
    <footer class="de-footer" role="contentinfo">
        <div class="de-container">
            <div class="de-footer-top">
                <!-- Column 1: Brand Info -->
                <div class="de-footer-brand">
                    <img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/assets/images/logo-white.svg'); ?>" alt="Marketing Agency" width="220" height="42">
                    <p>Marketing Agency is a premier international digital agency combining marketing, engineering, and creative strategy to accelerate business growth.</p>
                </div>

                <!-- Column 2: Quick Links -->
                <div>
                    <h3 class="de-footer-title">Quick Links</h3>
                    <ul class="de-footer-links">
                        <li><a href="<?php echo esc_url(home_url('/')); ?>">Home</a></li>
                        <li><a href="<?php echo esc_url(home_url('/about/')); ?>">About Us</a></li>
                        <li><a href="<?php echo esc_url(home_url('/services/')); ?>">All Services</a></li>
                        <li><a href="<?php echo esc_url(home_url('/partners/')); ?>">Our Partners</a></li>
                        <li><a href="<?php echo esc_url(home_url('/blog/')); ?>">Insights &amp; Blog</a></li>
                        <li><a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact Us</a></li>
                    </ul>
                </div>

                <!-- Column 3: All Services -->
                <div>
                    <h3 class="de-footer-title">Core Services</h3>
                    <ul class="de-footer-links">
                        <li><a href="<?php echo esc_url(home_url('/service/seo/')); ?>">Search Engine Optimization</a></li>
                        <li><a href="<?php echo esc_url(home_url('/service/ai-optimization/')); ?>">AI Search &amp; Optimization</a></li>
                        <li><a href="<?php echo esc_url(home_url('/service/wordpress-development/')); ?>">WordPress &amp; Elementor Dev</a></li>
                        <li><a href="<?php echo esc_url(home_url('/service/ui-ux-design/')); ?>">UI/UX &amp; Brand Systems</a></li>
                        <li><a href="<?php echo esc_url(home_url('/service/ecommerce-development/')); ?>">E-commerce Acceleration</a></li>
                        <li><a href="<?php echo esc_url(home_url('/service/video-production/')); ?>">Media &amp; Motion Production</a></li>
                    </ul>
                </div>

                <!-- Column 4: Newsletter & Contact -->
                <div class="de-footer-newsletter">
                    <h3 class="de-footer-title">Stay Ahead</h3>
                    <p>Subscribe to our quarterly intelligence memo on digital growth, algorithmic shifts, and AI tech.</p>
                    <form class="de-newsletter-form">
                        <input type="email" class="de-newsletter-input" placeholder="Your work email" required>
                        <button type="submit" class="de-btn de-btn-primary" style="padding: 10px 20px;">Join</button>
                    </form>
                    <div style="margin-top: 24px; font-size: 0.9rem; color: rgba(255,255,255,0.75);">
                        <p style="margin-bottom: 4px;"><strong>Direct Email:</strong> hello@marketingagency.local</p>
                        <p><strong>Phone:</strong> +1 (800) 555-0199</p>
                    </div>
                </div>
            </div>

            <div class="de-footer-bottom">
                <div>
                    &copy; <?php echo date('Y'); ?> Marketing Agency LLC. All rights reserved. Built for Elementor.
                </div>
                <div class="de-legal-links">
                    <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>">Privacy Policy</a>
                    <a href="<?php echo esc_url(home_url('/terms-conditions/')); ?>">Terms &amp; Conditions</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Consultation Modal -->
    <div id="consultationModal" class="de-modal-overlay">
        <div class="de-modal-card">
            <button class="de-modal-close" aria-label="Close dialog">&times;</button>
            <div class="de-form-title">Schedule a Free Growth Consultation</div>
            <div class="de-form-subtitle">Discuss your digital goals with our senior strategists. Zero sales pressure.</div>
            <form class="de-consultation-form">
                <div class="de-form-grid">
                    <div class="de-form-group">
                        <label class="de-form-label">First Name *</label>
                        <input type="text" class="de-input" name="first_name" required placeholder="Jane">
                    </div>
                    <div class="de-form-group">
                        <label class="de-form-label">Last Name *</label>
                        <input type="text" class="de-input" name="last_name" required placeholder="Doe">
                    </div>
                    <div class="de-form-group">
                        <label class="de-form-label">Work Email *</label>
                        <input type="email" class="de-input" name="email" required placeholder="jane@company.com">
                    </div>
                    <div class="de-form-group">
                        <label class="de-form-label">Phone Number</label>
                        <input type="tel" class="de-input" name="phone" placeholder="+1 (555) 000-0000">
                    </div>
                    <div class="de-form-group col-span-2">
                        <label class="de-form-label">Company Name</label>
                        <input type="text" class="de-input" name="company" placeholder="Acme Inc.">
                    </div>
                    <div class="de-form-group col-span-2">
                        <label class="de-form-label">Required Service</label>
                        <select class="de-select" name="service">
                            <option value="Digital Marketing & SEO">Digital Marketing &amp; SEO</option>
                            <option value="AI Optimization & Search">AI Optimization &amp; Search</option>
                            <option value="Website & WordPress Development">Website &amp; WordPress Development</option>
                            <option value="Creative Design & UI/UX">Creative Design &amp; UI/UX</option>
                            <option value="E-Commerce Growth">E-Commerce Growth</option>
                            <option value="Media & Motion Production">Media &amp; Motion Production</option>
                            <option value="Comprehensive Integrated Growth">Comprehensive Integrated Growth</option>
                        </select>
                    </div>
                    <div class="de-form-group col-span-2">
                        <label class="de-form-label">Project Scope &amp; Goals</label>
                        <textarea class="de-textarea" name="message" placeholder="Tell us about your current challenges, timeline, and growth objectives..."></textarea>
                    </div>
                    <div class="de-form-group col-span-2">
                        <button type="submit" class="de-btn de-btn-primary" style="width: 100%;">
                            Submit Consultation Request
                        </button>
                    </div>
                </div>
                <div class="de-form-status"></div>
            </form>
        </div>
    </div>
    <?php
}
?>

<?php wp_footer(); ?>
</body>
</html>
