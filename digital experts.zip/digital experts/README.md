# Digital Experts — WordPress & Elementor Digital Agency Website

A premium, modern, fully responsive digital agency website engineered specifically for **WordPress using Elementor**, following the reference agency architecture, section sequence, and transitions of [RankOrbit](https://rankorbit.com/) while establishing an original minimal white and emerald green brand identity.

## Quick Links
- **Interactive Browser Preview:** Open `preview/index.html` in any browser
- **WordPress Theme Zip:** `wordpress/digital-experts-theme.zip`
- **Elementor Templates Pack:** `wordpress/elementor-templates-pack.zip`
- **One-Click WXR Import:** `wordpress/import/digital-experts-wxr-export.xml`
- **Setup & Customization Guide:** [WORDPRESS_ELEMENTOR_SETUP_GUIDE.md](./WORDPRESS_ELEMENTOR_SETUP_GUIDE.md)

## Brand Identity & Color Palette
- **Primary Background:** `#FFFFFF`
- **Secondary Background:** `#F7FAF8`
- **Primary Emerald:** `#047857`
- **Deep Emerald:** `#064E3B`
- **Light Emerald:** `#D1FAE5`
- **Main Text:** `#171C19`
- **Secondary Text:** `#68736C`
- **Borders:** `#E5EBE7`
- **Headings:** Manrope / Plus Jakarta Sans
- **Body:** Inter

## Features
- **Sticky Glassmorphic Header & Services Mega Menu** (01 Digital Marketing, 02 Design, 03 Development, 04 Media Production)
- **14 Homepage Sections:** Hero with trust proof, Brand Introduction, Four Core Pillars, Continuous Partner Logo Marquee, Why Choose Us, Editorial Services, 4-Step Process, Selected Projects Portfolio, Client Testimonials, Google Reviews Proof, Interactive FAQ Accordion, Free Consultation Form, Final CTA, and Multi-Column Footer.
- **10 Complete Pages:** Home, About Us, Services Overview, Single Service, Our Partners, Blog Archive, Single Post, Contact Us, Privacy Policy, Terms & Conditions.
- **100% Elementor Editable:** Built with Flexbox Containers and native Elementor widgets. No shortcodes or locked code.
- **GSAP 3.12 & ScrollTrigger Animations:** Smooth fade-ins, card staggers, endless marquees, and responsive drawers.
