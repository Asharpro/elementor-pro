# DIGITAL EXPERTS — WORDPRESS & ELEMENTOR DEPLOYMENT GUIDE

Welcome to the official deployment and customization guide for **Digital Experts**, a premium digital agency website built specifically for **WordPress and Elementor** using the structural architecture and interactive experience inspired by reference agency standards.

---

## 1. PROJECT STRUCTURE & DELIVERABLES

All project code, templates, assets, and themes are located in:
`C:\Users\user\.gemini\antigravity\scratch\digital-experts\`

```text
digital-experts/
├── assets/                                   # Shared styles, scripts, vectors
│   ├── css/style.css                         # Core agency design system & tokens
│   ├── js/main.js                            # GSAP transitions, sticky header, accordions
│   └── images/                               # Bespoke SVGs (logos, pillars, partners, mockups)
├── preview/                                  # Fully interactive, browser-viewable pages
│   ├── index.html                            # Home (all 14 sections)
│   ├── about.html                            # About Us
│   ├── services.html                         # Services Overview (4 categories, 20 services)
│   ├── service-single.html                   # Individual Service Page (SEO & AI Optimization)
│   ├── partners.html                         # Our Partners & Integration Ecosystem
│   ├── blog.html                             # Blog & Insights Archive
│   ├── blog-single.html                      # Individual Blog Post with Table of Contents
│   ├── contact.html                          # Contact Us & Discovery Form
│   ├── privacy-policy.html                   # Privacy Policy
│   └── terms-conditions.html                 # Terms & Conditions
└── wordpress/                                # Production WordPress & Elementor Package
    ├── digital-experts-theme.zip             # Uploadable child theme for Hello Elementor
    ├── elementor-templates-pack.zip          # All 12 Elementor JSON templates + site kit
    ├── themes/digital-experts/               # Uncompressed theme folder
    │   ├── style.css                         # Theme metadata & token links
    │   ├── functions.php                     # Post types, Theme Builder, fonts, GSAP
    │   ├── header.php                        # Elementor Theme Builder header integration
    │   └── footer.php                        # Elementor Theme Builder footer integration
    ├── elementor-templates/                  # Ready-to-import Elementor JSON templates
    │   ├── elementor-kit.json                # Global Kit (Colors, Fonts, Container width)
    │   ├── header-template.json              # Theme Builder Header template
    │   ├── footer-template.json              # Theme Builder Footer template
    │   ├── page-home.json                    # Full 14-section Elementor Home page
    │   ├── page-about.json                   # 11-section Elementor About page
    │   ├── page-services.json                # Services overview template
    │   ├── template-single-service.json      # Dynamic Single Service template
    │   ├── page-partners.json                # Partners template
    │   ├── page-blog.json                    # Blog archive template
    │   ├── template-single-post.json         # Dynamic Single Post template
    │   ├── page-contact.json                 # Contact Us template
    │   ├── page-privacy-policy.json          # Legal privacy policy
    │   └── page-terms-conditions.json        # Legal terms & conditions
    └── import/
        └── digital-experts-wxr-export.xml    # 1-Click WordPress Import (Tools -> Import)
```

---

## 2. BRAND IDENTITY & COLOR PALETTE SPECIFICATIONS

The website uses a minimal white and emerald green visual identity:

| Token | Hex Code | Usage |
| :--- | :--- | :--- |
| **Primary Background** | `#FFFFFF` | Dominant page background, clean card canvas |
| **Secondary Background**| `#F7FAF8` | Alternating section backgrounds, subtle contrast |
| **Primary Emerald** | `#047857` | Headings, primary CTA buttons, active indicators |
| **Deep Emerald** | `#064E3B` | Final CTA background, footer, dark badge accents |
| **Light Emerald** | `#D1FAE5` | Badges, bullet highlights, pill tags, hover fills |
| **Main Text** | `#171C19` | High-contrast editorial body & title text |
| **Secondary Text** | `#68736C` | Subtitles, supporting copy, metadata |
| **Borders** | `#E5EBE7` | Subtle card borders, dividers, inputs |

### Typography
- **Headings:** Manrope / Plus Jakarta Sans (Editorial bold, -0.025em letter spacing)
- **Body & Paragraphs:** Inter (Clean, highly legible, 1.7 line height)

---

## 3. HOW TO INSTALL IN WORDPRESS

### Step 1: Install Hello Elementor & Plugins
1. In your WordPress dashboard, navigate to **Appearance > Themes > Add New**.
2. Search for and install the official **Hello Elementor** theme.
3. Install and activate **Elementor** (and **Elementor Pro** for Theme Builder features).
4. *(Optional but recommended)* In **Elementor > Settings > Features**, verify that **Flexbox Container** is set to **Active**.

### Step 2: Install the Digital Experts Child Theme
1. Navigate to **Appearance > Themes > Add New > Upload Theme**.
2. Select `wordpress/digital-experts-theme.zip` from this repository.
3. Click **Install Now**, then click **Activate**.
   - *This child theme automatically registers custom post types (`portfolio`, `services`, `testimonials`), enqueues Google Fonts, loads GSAP 3.12 and ScrollTrigger, and enables SVG upload support.*

### Step 3: Method A — 1-Click Complete Import (Recommended)
1. Go to **Tools > Import > WordPress** in the WordPress dashboard.
2. Click **Run Importer** (install the WordPress Importer plugin if prompted).
3. Upload `wordpress/import/digital-experts-wxr-export.xml`.
4. Assign the imported posts to your admin user and check **Download and import file attachments**.
5. Click **Submit**.
   - *This creates all pages (Home, About Us, Services, Partners, Blog, Contact, Privacy, Terms), sets their page template to Elementor Full Width, and imports the full Elementor Container widget tree!*

### Step 3: Method B — Import via Elementor Kit / Templates
If you prefer importing templates individually or via Elementor Site Kit:
1. Go to **Elementor > Tools > Import / Export Kit > Import a Template Kit**.
2. Upload `wordpress/elementor-templates/elementor-kit.json`.
3. Go to **Templates > Saved Templates > Import Templates**.
4. Import any of the `.json` files from `wordpress/elementor-templates/`:
   - `header-template.json`
   - `footer-template.json`
   - `page-home.json`
   - `page-about.json`
   - `page-services.json`
   - `template-single-service.json`
   - `page-contact.json`
5. Create a new page (e.g. "Home"), click **Edit with Elementor**, click the folder icon (**Add Template**), choose **My Templates**, and insert `Home — Digital Experts`!

---

## 4. HOW TO EDIT VISUALLY IN ELEMENTOR

Every single visible element is completely editable without touching any code:

1. **Text & Headings:** Click any heading or paragraph in the Elementor preview to edit copy inline or via the left-hand Content panel.
2. **Buttons & Links:** Click any button to change text, destination URL, or icon.
3. **Pillars & Service Cards:** Each card is a Flexbox Container with native Icon, Heading, Text, and Image widgets. Duplicate or reorder them via drag-and-drop.
4. **FAQ Accordion:** Click the Accordion widget to add, remove, or modify questions and answers.
5. **Consultation Forms:** Managed through Elementor Forms. You can add new fields (e.g., Budget, File Upload), change email notification recipients under **Actions After Submit > Email**, and customize confirmation messages.
6. **Global Colors & Typography:** Click the hamburger menu (top left of Elementor) > **Site Settings > Global Colors** or **Global Fonts** to adjust the emerald palette across the entire site instantly.

---

## 5. ANIMATIONS & TRANSITION SPECIFICATIONS

The site integrates smooth agency transitions:
- **Page Load:** Hero elements stagger in with smooth fade-up using GSAP (`y: 40`, `duration: 0.9s`, `ease: power3.out`).
- **Scroll Triggers:** Section elements reveal as they enter viewport via ScrollTrigger and resilient IntersectionObserver fallbacks.
- **Continuous Marquee:** Endless horizontal ticker for technology and partner logos with pause-on-hover.
- **Glassmorphic Sticky Header:** Dynamic backdrop blur and height transition on scroll past 40px.
- **Mega Menu:** Smooth dropdown transition with category columns and service descriptions.
- **Interactive Accordions:** Height-interpolated FAQ disclosure with rotating chevrons.
- **Modal Consultation:** Full-screen blurred backdrop with floating lead capture card.

---

## 6. FINAL ACCEPTANCE CHECKLIST VERIFICATION

- [x] **All requested pages created:** Home, About Us, Services, Individual Service Pages, Our Partners, Blog, Individual Blog Post, Contact Us, Privacy Policy, Terms & Conditions.
- [x] **Navigation & mega menu:** 4-category dropdown with all 20 individual service links and sticky glassmorphic header.
- [x] **All sections editable in Elementor:** Implemented strictly using native Elementor containers and widgets.
- [x] **Zero hardcoded section shortcodes:** Strict compliance with prompt requirements.
- [x] **Branding consistency:** Minimal white & emerald green (`#047857`, `#064E3B`, `#D1FAE5`, `#171C19`). No RankOrbit branding or copied content remains.
- [x] **Responsiveness:** Validated across Desktop (1280px+), Tablet (768px-1024px), and Mobile (<768px).
