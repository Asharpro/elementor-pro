$port = 8080
$rootDir = "C:\Users\user\.gemini\antigravity\scratch\digital-experts"

$listener = New-Object System.Net.HttpListener
$prefix = "http://localhost:$port/"
$listener.Prefixes.Add($prefix)

try {
    $listener.Start()
    Write-Host "=========================================================="
    Write-Host " DIGITAL EXPERTS WEB SERVER IS RUNNING"
    Write-Host " URL: $prefix"
    Write-Host " Root Directory: $rootDir"
    Write-Host "=========================================================="
} catch {
    Write-Error "Failed to start listener on $prefix : $_"
    exit 1
}

$mimeTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".htm"  = "text/html; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".svg"  = "image/svg+xml"
    ".xml"  = "application/xml; charset=utf-8"
    ".png"  = "image/png"
    ".jpg"  = "image/jpeg"
    ".jpeg" = "image/jpeg"
    ".gif"  = "image/gif"
    ".ico"  = "image/x-icon"
    ".zip"  = "application/zip"
    ".txt"  = "text/plain; charset=utf-8"
}

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        $rawUrl = $request.RawUrl.Split('?')[0]
        $cleanPath = $rawUrl.TrimStart('/')

        if ($cleanPath -eq "" -or $cleanPath -eq "/") {
            $filePath = Join-Path $rootDir "preview\index.html"
        } else {
            $candidate1 = Join-Path $rootDir ($cleanPath.Replace('/', '\'))
            $candidate2 = Join-Path $rootDir ("preview\" + $cleanPath.Replace('/', '\'))

            if (Test-Path $candidate1 -PathType Leaf) {
                $filePath = $candidate1
            } elseif (Test-Path $candidate2 -PathType Leaf) {
                $filePath = $candidate2
            } elseif (Test-Path (Join-Path $candidate1 "index.html") -PathType Leaf) {
                $filePath = Join-Path $candidate1 "index.html"
            } elseif (Test-Path (Join-Path $candidate2 "index.html") -PathType Leaf) {
                $filePath = Join-Path $candidate2 "index.html"
            } else {
                $filePath = $null
            }
        }

        if ($filePath -and (Test-Path $filePath -PathType Leaf)) {
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            $mime = if ($mimeTypes.ContainsKey($ext)) { $mimeTypes[$ext] } else { "application/octet-stream" }
            $bytes = [System.IO.File]::ReadAllBytes($filePath)

            $response.ContentType = $mime
            $response.ContentLength64 = $bytes.Length
            $response.StatusCode = 200
            $response.Headers.Add("Access-Control-Allow-Origin", "*")

            if ($request.HttpMethod -ne "HEAD") {
                $response.OutputStream.Write($bytes, 0, $bytes.Length)
            }
        } else {
            $response.StatusCode = 404
            $errText = "<h1>404 Not Found</h1><p>Resource '$rawUrl' not found.</p><p><a href='/'>Go to Digital Experts Home</a></p>"
            $errBytes = [System.Text.Encoding]::UTF8.GetBytes($errText)
            $response.ContentType = "text/html; charset=utf-8"
            $response.ContentLength64 = $errBytes.Length
            if ($request.HttpMethod -ne "HEAD") {
                $response.OutputStream.Write($errBytes, 0, $errBytes.Length)
            }
        }

        $response.Close()
    } catch {
        # Continue on client abort
    }
}
