<?php
/**
 * Footer template for Digital Experts
 * Compatible with Elementor Theme Builder
 */
if (!defined('ABSPATH')) {
    exit;
}
?>
</main><!-- #primary -->

<?php
if (!function_exists('elementor_theme_do_location') || !elementor_theme_do_location('footer')) {
    // Fallback native footer if Elementor Theme Builder Footer is not assigned
    ?>
    <footer class="de-footer" role="contentinfo">
        <div class="de-container">
            <div class="de-footer-top">
                <!-- Column 1: Brand Info -->
                <div class="de-footer-brand">
                    <img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/assets/images/logo-white.svg'); ?>" alt="Digital Experts" width="220" height="42">
                    <p>Digital Experts is a premier international digital agency combining marketing, engineering, and creative strategy to accelerate business growth.</p>
                    <div style="display: flex; gap: 14px; margin-top: 16px;">
                        <a href="https://linkedin.com" target="_blank" rel="noopener" style="color: #34D399; font-size: 1.1rem;" aria-label="LinkedIn">
                            <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                        </a>
                        <a href="https://twitter.com" target="_blank" rel="noopener" style="color: #34D399; font-size: 1.1rem;" aria-label="Twitter">
                            <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                        </a>
                        <a href="https://github.com" target="_blank" rel="noopener" style="color: #34D399; font-size: 1.1rem;" aria-label="GitHub">
                            <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
                        </a>
                    </div>
                </div>

                <!-- Column 2: Quick Links -->
                <div>
                    <h3 class="de-footer-title">Quick Links</h3>
                    <ul class="de-footer-links">
                        <li><a href="<?php echo esc_url(home_url('/')); ?>">Home</a></li>
                        <li><a href="<?php echo esc_url(home_url('/about/')); ?>">About Us</a></li>
                        <li><a href="<?php echo esc_url(home_url('/services/')); ?>">All Services</a></li>
                        <li><a href="<?php echo esc_url(home_url('/partners/')); ?>">Our Partners</a></li>
                        <li><a href="<?php echo esc_url(home_url('/blog/')); ?>">Insights &amp; Blog</a></li>
                        <li><a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact Us</a></li>
                    </ul>
                </div>

                <!-- Column 3: All Services -->
                <div>
                    <h3 class="de-footer-title">Core Services</h3>
                    <ul class="de-footer-links">
                        <li><a href="<?php echo esc_url(home_url('/service/seo/')); ?>">Search Engine Optimization</a></li>
                        <li><a href="<?php echo esc_url(home_url('/service/ai-optimization/')); ?>">AI Search &amp; Optimization</a></li>
                        <li><a href="<?php echo esc_url(home_url('/service/wordpress-development/')); ?>">WordPress &amp; Elementor Dev</a></li>
                        <li><a href="<?php echo esc_url(home_url('/service/ui-ux-design/')); ?>">UI/UX &amp; Brand Systems</a></li>
                        <li><a href="<?php echo esc_url(home_url('/service/ecommerce-development/')); ?>">E-commerce Acceleration</a></li>
                        <li><a href="<?php echo esc_url(home_url('/service/video-production/')); ?>">Media &amp; Motion Production</a></li>
                    </ul>
                </div>

                <!-- Column 4: Newsletter & Contact -->
                <div class="de-footer-newsletter">
                    <h3 class="de-footer-title">Stay Ahead</h3>
                    <p>Subscribe to our quarterly intelligence memo on digital growth, algorithmic shifts, and AI tech.</p>
                    <form class="de-newsletter-form">
                        <input type="email" class="de-newsletter-input" placeholder="Your work email" required>
                        <button type="submit" class="de-btn de-btn-primary" style="padding: 10px 20px;">Join</button>
                    </form>
                    <div style="margin-top: 24px; font-size: 0.9rem; color: rgba(255,255,255,0.75);">
                        <p style="margin-bottom: 4px;"><strong>Global Inquiries:</strong> hello@digitalexperts.io</p>
                        <p><strong>Strategy Desk:</strong> +1 (800) 555-0199</p>
                    </div>
                </div>
            </div>

            <div class="de-footer-bottom">
                <div>
                    &copy; <?php echo date('Y'); ?> Digital Experts LLC. All rights reserved. Built for Elementor.
                </div>
                <div class="de-legal-links">
                    <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>">Privacy Policy</a>
                    <a href="<?php echo esc_url(home_url('/terms-conditions/')); ?>">Terms &amp; Conditions</a>
                    <a href="<?php echo esc_url(home_url('/sitemap.xml')); ?>">Sitemap</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Consultation Modal -->
    <div id="consultationModal" class="de-modal-overlay">
        <div class="de-modal-card">
            <button class="de-modal-close" aria-label="Close dialog">&times;</button>
            <div class="de-form-title">Schedule a Free Growth Consultation</div>
            <div class="de-form-subtitle">Discuss your digital goals with our senior strategists. Zero sales pressure.</div>
            <form class="de-consultation-form">
                <div class="de-form-grid">
                    <div class="de-form-group">
                        <label class="de-form-label">First Name *</label>
                        <input type="text" class="de-input" name="first_name" required placeholder="Jane">
                    </div>
                    <div class="de-form-group">
                        <label class="de-form-label">Last Name *</label>
                        <input type="text" class="de-input" name="last_name" required placeholder="Doe">
                    </div>
                    <div class="de-form-group">
                        <label class="de-form-label">Work Email *</label>
                        <input type="email" class="de-input" name="email" required placeholder="jane@company.com">
                    </div>
                    <div class="de-form-group">
                        <label class="de-form-label">Phone Number</label>
                        <input type="tel" class="de-input" name="phone" placeholder="+1 (555) 000-0000">
                    </div>
                    <div class="de-form-group col-span-2">
                        <label class="de-form-label">Company Name</label>
                        <input type="text" class="de-input" name="company" placeholder="Acme Inc.">
                    </div>
                    <div class="de-form-group col-span-2">
                        <label class="de-form-label">Required Service</label>
                        <select class="de-select" name="service">
                            <option value="Digital Marketing & SEO">Digital Marketing &amp; SEO</option>
                            <option value="AI Optimization & Search">AI Optimization &amp; Search</option>
                            <option value="Website & WordPress Development">Website &amp; WordPress Development</option>
                            <option value="Creative Design & UI/UX">Creative Design &amp; UI/UX</option>
                            <option value="E-Commerce Growth">E-Commerce Growth</option>
                            <option value="Media & Motion Production">Media &amp; Motion Production</option>
                            <option value="Comprehensive Integrated Growth">Comprehensive Integrated Growth</option>
                        </select>
                    </div>
                    <div class="de-form-group col-span-2">
                        <label class="de-form-label">Project Scope &amp; Goals</label>
                        <textarea class="de-textarea" name="message" placeholder="Tell us about your current challenges, timeline, and growth objectives..."></textarea>
                    </div>
                    <div class="de-form-group col-span-2">
                        <button type="submit" class="de-btn de-btn-primary" style="width: 100%;">
                            Submit Consultation Request
                            <span class="de-btn-arrow"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1 7H13M13 7L7.5 1.5M13 7L7.5 12.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
                        </button>
                    </div>
                </div>
                <div class="de-form-status"></div>
            </form>
        </div>
    </div>
    <?php
}
?>

<?php wp_footer(); ?>
</body>
</html>
