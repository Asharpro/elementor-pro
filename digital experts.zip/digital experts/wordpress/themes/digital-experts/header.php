<?php
/**
 * Header template for Digital Experts
 * Works seamlessly with Elementor Theme Builder
 */
if (!defined('ABSPATH')) {
    exit;
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php
if (!function_exists('elementor_theme_do_location') || !elementor_theme_do_location('header')) {
    // Fallback native header if Elementor Theme Builder Header is not assigned
    ?>
    <header class="de-header-wrapper" role="banner">
        <div class="de-container">
            <div class="de-header-inner">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="de-brand-logo" rel="home">
                    <?php if (has_custom_logo()) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/assets/images/logo.svg'); ?>" alt="Digital Experts" width="220" height="42">
                    <?php endif; ?>
                </a>

                <nav class="de-nav-menu" role="navigation" aria-label="Main Navigation">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="de-nav-link">Home</a>
                    
                    <div class="de-has-mega">
                        <a href="<?php echo esc_url(home_url('/services/')); ?>" class="de-nav-link">
                            Services
                            <svg class="caret-icon" viewBox="0 0 12 12" fill="none"><path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                        </a>
                        <div class="de-mega-menu">
                            <div class="de-container">
                                <div class="de-mega-content">
                                    <!-- 01 Digital Marketing -->
                                    <div class="de-mega-col">
                                        <div class="de-mega-category-title">01. Digital Marketing</div>
                                        <div class="de-mega-links-list">
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/seo/')); ?>"><span class="de-mega-item-name">SEO</span><span class="de-mega-item-desc">Engineered search rankings &amp; organic authority</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/ai-optimization/')); ?>"><span class="de-mega-item-name">AI Optimization</span><span class="de-mega-item-desc">Generative search &amp; model fine-tuning</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/performance-marketing/')); ?>"><span class="de-mega-item-name">Performance Marketing</span><span class="de-mega-item-desc">High-ROAS paid media &amp; retargeting</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/email-marketing/')); ?>"><span class="de-mega-item-name">Email Marketing</span><span class="de-mega-item-desc">Automated lifecycle CRM &amp; retention</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/sem/')); ?>"><span class="de-mega-item-name">Search Engine Marketing</span><span class="de-mega-item-desc">Precision Google Ads &amp; intent capture</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/social-media/')); ?>"><span class="de-mega-item-name">Social Media Marketing</span><span class="de-mega-item-desc">Omnichannel creative storytelling</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/reputation-management/')); ?>"><span class="de-mega-item-name">Reputation Management</span><span class="de-mega-item-desc">Executive brand trust &amp; review signals</span></a></div>
                                        </div>
                                    </div>

                                    <!-- 02 Design -->
                                    <div class="de-mega-col">
                                        <div class="de-mega-category-title">02. Design</div>
                                        <div class="de-mega-links-list">
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/brand-identity/')); ?>"><span class="de-mega-item-name">Brand Identity</span><span class="de-mega-item-desc">Logos, visual systems, brand books</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/ui-ux-design/')); ?>"><span class="de-mega-item-name">UI/UX Design</span><span class="de-mega-item-desc">Human-centric wireframes &amp; high-fidelity web apps</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/graphic-design/')); ?>"><span class="de-mega-item-name">Graphic Design</span><span class="de-mega-item-desc">Editorial collateral &amp; marketing assets</span></a></div>
                                        </div>
                                    </div>

                                    <!-- 03 Development -->
                                    <div class="de-mega-col">
                                        <div class="de-mega-category-title">03. Development</div>
                                        <div class="de-mega-links-list">
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/website-development/')); ?>"><span class="de-mega-item-name">Website Development</span><span class="de-mega-item-desc">Custom enterprise architectures</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/wordpress-development/')); ?>"><span class="de-mega-item-name">WordPress Development</span><span class="de-mega-item-desc">Elementor-driven, performant CMS systems</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/ecommerce-development/')); ?>"><span class="de-mega-item-name">E-commerce Development</span><span class="de-mega-item-desc">WooCommerce &amp; Shopify high-conversion stores</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/web-app-development/')); ?>"><span class="de-mega-item-name">Web Application Dev</span><span class="de-mega-item-desc">React, Node, modern cloud stacks</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/mobile-app-development/')); ?>"><span class="de-mega-item-name">Mobile App Development</span><span class="de-mega-item-desc">iOS &amp; Android cross-platform</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/custom-software/')); ?>"><span class="de-mega-item-name">Custom Software Dev</span><span class="de-mega-item-desc">Scalable APIs &amp; internal platforms</span></a></div>
                                        </div>
                                    </div>

                                    <!-- 04 Media Production -->
                                    <div class="de-mega-col">
                                        <div class="de-mega-category-title">04. Media Production</div>
                                        <div class="de-mega-links-list">
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/video-editing/')); ?>"><span class="de-mega-item-name">Video Editing</span><span class="de-mega-item-desc">High-pace social &amp; corporate editing</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/animation/')); ?>"><span class="de-mega-item-name">Animation</span><span class="de-mega-item-desc">2D &amp; 3D narrative brand explainers</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/motion-graphics/')); ?>"><span class="de-mega-item-name">Motion Graphics</span><span class="de-mega-item-desc">Dynamic typography &amp; UI micro-interactions</span></a></div>
                                            <div class="de-mega-item"><a href="<?php echo esc_url(home_url('/service/video-production/')); ?>"><span class="de-mega-item-name">Video Production</span><span class="de-mega-item-desc">Commercial shoots &amp; documentary media</span></a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <a href="<?php echo esc_url(home_url('/about/')); ?>" class="de-nav-link">About</a>
                    <a href="<?php echo esc_url(home_url('/partners/')); ?>" class="de-nav-link">Our Partners</a>
                    <a href="<?php echo esc_url(home_url('/blog/')); ?>" class="de-nav-link">Blog</a>
                    <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="de-nav-link">Contact Us</a>
                </nav>

                <div class="de-header-actions">
                    <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="de-btn de-btn-primary" data-open-consultation>
                        Book a Free Consultation
                        <span class="de-btn-arrow"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1 7H13M13 7L7.5 1.5M13 7L7.5 12.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
                    </a>

                    <button class="de-mobile-toggle" aria-label="Toggle Navigation Menu">
                        <svg width="26" height="26" viewBox="0 0 24 24" fill="none"><path d="M4 6H20M4 12H20M4 18H20" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>
                    </button>
                </div>
            </div>
        </div>
    </header>

    <!-- Mobile Drawer -->
    <div class="de-mobile-overlay"></div>
    <div class="de-mobile-drawer" role="dialog" aria-modal="true">
        <div class="de-mobile-header">
            <img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/assets/images/logo.svg'); ?>" alt="Digital Experts" width="180">
            <button class="de-mobile-close" aria-label="Close menu">&times;</button>
        </div>
        <nav class="de-mobile-nav">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="de-mobile-link">Home</a>
            <button class="de-mobile-dropdown-btn" data-target="mSubServices">
                Services <span>&#9662;</span>
            </button>
            <div id="mSubServices" class="de-mobile-subnav">
                <a href="<?php echo esc_url(home_url('/services/')); ?>" class="de-mobile-sublink"><strong>All Services Overview</strong></a>
                <a href="<?php echo esc_url(home_url('/service/seo/')); ?>" class="de-mobile-sublink">Search Engine Optimization</a>
                <a href="<?php echo esc_url(home_url('/service/ai-optimization/')); ?>" class="de-mobile-sublink">AI Optimization</a>
                <a href="<?php echo esc_url(home_url('/service/wordpress-development/')); ?>" class="de-mobile-sublink">WordPress Development</a>
                <a href="<?php echo esc_url(home_url('/service/ui-ux-design/')); ?>" class="de-mobile-sublink">UI/UX Design</a>
            </div>
            <a href="<?php echo esc_url(home_url('/about/')); ?>" class="de-mobile-link">About Us</a>
            <a href="<?php echo esc_url(home_url('/partners/')); ?>" class="de-mobile-link">Our Partners</a>
            <a href="<?php echo esc_url(home_url('/blog/')); ?>" class="de-mobile-link">Blog</a>
            <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="de-mobile-link">Contact Us</a>
            <div style="margin-top: 24px;">
                <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="de-btn de-btn-primary" style="width: 100%;" data-open-consultation>Book a Free Consultation</a>
            </div>
        </nav>
    </div>
    <?php
}
?>

<main id="primary" class="site-main">
