<?php
/**
 * Digital Experts Theme Functions & Definitions
 * Built exclusively for Elementor Pro & Hello Elementor
 *
 * @package DigitalExperts
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('DIGITAL_EXPERTS_VERSION', '1.0.0');

/**
 * Enqueue scripts and styles.
 */
function digital_experts_scripts() {
    // 1. Parent theme style
    wp_enqueue_style('hello-elementor-parent', get_template_directory_uri() . '/style.css');

    // 2. Google Fonts: Manrope, Plus Jakarta Sans, Inter
    wp_enqueue_style(
        'digital-experts-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Manrope:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap',
        array(),
        null
    );

    // 3. Child Theme Stylesheet
    wp_enqueue_style(
        'digital-experts-core-style',
        get_stylesheet_directory_uri() . '/assets/css/style.css',
        array('hello-elementor-parent'),
        DIGITAL_EXPERTS_VERSION
    );

    // 4. GSAP 3.12 & ScrollTrigger for premium agency transitions
    wp_enqueue_script(
        'gsap',
        'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js',
        array(),
        '3.12.5',
        true
    );

    wp_enqueue_script(
        'gsap-scroll-trigger',
        'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js',
        array('gsap'),
        '3.12.5',
        true
    );

    // 5. Agency Main Script
    wp_enqueue_script(
        'digital-experts-main',
        get_stylesheet_directory_uri() . '/assets/js/main.js',
        array('jquery', 'gsap', 'gsap-scroll-trigger'),
        DIGITAL_EXPERTS_VERSION,
        true
    );

    // Localize script for ajax form submission
    wp_localize_script('digital-experts-main', 'deAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('de_consultation_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'digital_experts_scripts', 20);

/**
 * Theme Setup & Elementor Support
 */
function digital_experts_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 80,
        'width'       => 260,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    add_theme_support('align-wide');
    add_theme_support('responsive-embeds');

    // Register Navigation Menus
    register_nav_menus(array(
        'primary-menu'   => __('Primary Header Menu', 'digital-experts'),
        'mega-marketing' => __('Services: Digital Marketing', 'digital-experts'),
        'mega-design'    => __('Services: Design', 'digital-experts'),
        'mega-dev'       => __('Services: Development', 'digital-experts'),
        'mega-media'     => __('Services: Media Production', 'digital-experts'),
        'footer-quick'   => __('Footer Quick Links', 'digital-experts'),
        'footer-legal'   => __('Footer Legal Links', 'digital-experts')
    ));
}
add_action('after_setup_theme', 'digital_experts_setup');

/**
 * Register Custom Post Types for Portfolio, Services, and Testimonials
 */
function digital_experts_register_post_types() {
    // 1. Selected Projects / Portfolio
    register_post_type('portfolio', array(
        'labels' => array(
            'name'               => __('Portfolio Projects', 'digital-experts'),
            'singular_name'      => __('Portfolio Project', 'digital-experts'),
            'add_new'            => __('Add New Project', 'digital-experts'),
            'add_new_item'       => __('Add New Portfolio Project', 'digital-experts'),
            'edit_item'          => __('Edit Project', 'digital-experts'),
            'all_items'          => __('All Projects', 'digital-experts'),
            'menu_name'          => __('Portfolio', 'digital-experts')
        ),
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => array('slug' => 'portfolio'),
        'supports'     => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'elementor'),
        'menu_icon'    => 'dashicons-portfolio',
        'show_in_rest' => true
    ));

    register_taxonomy('portfolio_category', 'portfolio', array(
        'labels' => array(
            'name'          => __('Project Categories', 'digital-experts'),
            'singular_name' => __('Project Category', 'digital-experts')
        ),
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true
    ));

    // 2. Individual Services
    register_post_type('services', array(
        'labels' => array(
            'name'               => __('Services', 'digital-experts'),
            'singular_name'      => __('Service', 'digital-experts'),
            'add_new'            => __('Add New Service', 'digital-experts'),
            'add_new_item'       => __('Add New Service', 'digital-experts'),
            'edit_item'          => __('Edit Service', 'digital-experts'),
            'all_items'          => __('All Services', 'digital-experts'),
            'menu_name'          => __('Services', 'digital-experts')
        ),
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => array('slug' => 'service'),
        'supports'     => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'elementor'),
        'menu_icon'    => 'dashicons-networking',
        'show_in_rest' => true
    ));

    register_taxonomy('service_category', 'services', array(
        'labels' => array(
            'name'          => __('Service Categories', 'digital-experts'),
            'singular_name' => __('Service Category', 'digital-experts')
        ),
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true
    ));

    // 3. Client Testimonials
    register_post_type('testimonials', array(
        'labels' => array(
            'name'               => __('Testimonials', 'digital-experts'),
            'singular_name'      => __('Testimonial', 'digital-experts'),
            'add_new'            => __('Add New Testimonial', 'digital-experts'),
            'all_items'          => __('All Testimonials', 'digital-experts'),
            'menu_name'          => __('Testimonials', 'digital-experts')
        ),
        'public'       => false,
        'show_ui'      => true,
        'supports'     => array('title', 'editor', 'thumbnail', 'custom-fields'),
        'menu_icon'    => 'dashicons-testimonial',
        'show_in_rest' => true
    ));
}
add_action('init', 'digital_experts_register_post_types');

/**
 * Register Elementor Theme Builder Locations
 */
function digital_experts_register_elementor_locations($elementor_theme_manager) {
    $elementor_theme_manager->register_location('header');
    $elementor_theme_manager->register_location('footer');
    $elementor_theme_manager->register_location('single');
    $elementor_theme_manager->register_location('archive');
}
add_action('elementor/theme/register_locations', 'digital_experts_register_elementor_locations');

/**
 * Ensure Elementor enables Flexbox Container & Custom Post Types
 */
function digital_experts_elementor_init() {
    // Add custom post types to Elementor editable types
    $cpts = get_option('elementor_cpt_support', array('post', 'page'));
    $custom = array('portfolio', 'services');
    foreach ($custom as $cpt) {
        if (!in_array($cpt, $cpts)) {
            $cpts[] = $cpt;
        }
    }
    update_option('elementor_cpt_support', $cpts);

    // Enable Flexbox Container experiment by default
    update_option('elementor_experiment-container', 'active');
}
add_action('after_switch_theme', 'digital_experts_elementor_init');

/**
 * Enable SVG Uploads in WordPress Media Library
 */
function digital_experts_mime_types($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    $mimes['svgz'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'digital_experts_mime_types');

/**
 * AJAX Consultation Form Handler
 */
function digital_experts_handle_consultation() {
    check_ajax_referer('de_consultation_nonce', 'nonce');

    $first_name = sanitize_text_field($_POST['first_name'] ?? '');
    $last_name  = sanitize_text_field($_POST['last_name'] ?? '');
    $email      = sanitize_email($_POST['email'] ?? '');
    $phone      = sanitize_text_field($_POST['phone'] ?? '');
    $company    = sanitize_text_field($_POST['company'] ?? '');
    $service    = sanitize_text_field($_POST['service'] ?? '');
    $message    = sanitize_textarea_field($_POST['message'] ?? '');

    if (empty($email) || empty($first_name)) {
        wp_send_json_error(array('message' => 'Please provide your name and a valid email address.'));
    }

    $admin_email = get_option('admin_email');
    $subject = sprintf('[Digital Experts Consultation] New Inquiry from %s %s', $first_name, $last_name);
    $body = "New Growth Consultation Request:\n\n"
          . "Name: $first_name $last_name\n"
          . "Email: $email\n"
          . "Phone: $phone\n"
          . "Company: $company\n"
          . "Service Required: $service\n"
          . "Project Scope:\n$message\n\n"
          . "Received on: " . current_time('mysql');

    $headers = array('Content-Type: text/plain; charset=UTF-8', "Reply-To: $first_name $last_name <$email>");

    @wp_mail($admin_email, $subject, $body, $headers);

    wp_send_json_success(array('message' => 'Consultation inquiry submitted successfully.'));
}
add_action('wp_ajax_digital_experts_consultation', 'digital_experts_handle_consultation');
add_action('wp_ajax_nopriv_digital_experts_consultation', 'digital_experts_handle_consultation');
