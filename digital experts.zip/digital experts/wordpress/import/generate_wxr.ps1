$homeJson = [System.IO.File]::ReadAllText('C:\Users\user\.gemini\antigravity\scratch\digital-experts\wordpress\elementor-templates\page-home.json')
$aboutJson = [System.IO.File]::ReadAllText('C:\Users\user\.gemini\antigravity\scratch\digital-experts\wordpress\elementor-templates\page-about.json')
$servicesJson = [System.IO.File]::ReadAllText('C:\Users\user\.gemini\antigravity\scratch\digital-experts\wordpress\elementor-templates\page-services.json')
$partnersJson = [System.IO.File]::ReadAllText('C:\Users\user\.gemini\antigravity\scratch\digital-experts\wordpress\elementor-templates\page-partners.json')
$contactJson = [System.IO.File]::ReadAllText('C:\Users\user\.gemini\antigravity\scratch\digital-experts\wordpress\elementor-templates\page-contact.json')

$wxr = @"
<?xml version="1.0" encoding="UTF-8" ?>
<!-- generator="WordPress/6.4.3" created="2026-11-02 06:30" -->
<rss version="2.0"
	xmlns:excerpt="http://wordpress.org/export/1.2/excerpt/"
	xmlns:content="http://purl.org/rss/1.0/modules/content/"
	xmlns:wfw="http://wellformedweb.org/CommentAPI/"
	xmlns:dc="http://purl.org/dc/elements/1.1/"
	xmlns:wp="http://wordpress.org/export/1.2/"
>
<channel>
	<title>Digital Experts</title>
	<link>https://digitalexperts.io</link>
	<description>Premier International Digital Agency &amp; Technology Partner</description>
	<pubDate>Mon, 02 Nov 2026 06:30:00 +0000</pubDate>
	<language>en-US</language>
	<wp:wxr_version>1.2</wp:wxr_version>
	<wp:base_site_url>https://digitalexperts.io</wp:base_site_url>
	<wp:base_blog_url>https://digitalexperts.io</wp:base_blog_url>

	<!-- PAGE 1: HOME -->
	<item>
		<title>Home</title>
		<link>https://digitalexperts.io/</link>
		<pubDate>Mon, 02 Nov 2026 06:00:00 +0000</pubDate>
		<dc:creator><![CDATA[admin]]></dc:creator>
		<guid isPermaLink="false">https://digitalexperts.io/?page_id=10</guid>
		<description></description>
		<content:encoded><![CDATA[]]></content:encoded>
		<excerpt:encoded><![CDATA[]]></excerpt:encoded>
		<wp:post_id>10</wp:post_id>
		<wp:post_date>2026-11-02 06:00:00</wp:post_date>
		<wp:post_date_gmt>2026-11-02 06:00:00</wp:post_date_gmt>
		<wp:comment_status>closed</wp:comment_status>
		<wp:ping_status>closed</wp:ping_status>
		<wp:post_name>home</wp:post_name>
		<wp:status>publish</wp:status>
		<wp:post_parent>0</wp:post_parent>
		<wp:menu_order>1</wp:menu_order>
		<wp:post_type>page</wp:post_type>
		<wp:post_password></wp:post_password>
		<wp:is_sticky>0</wp:is_sticky>
		<wp:postmeta>
			<wp:meta_key>_wp_page_template</wp:meta_key>
			<wp:meta_value><![CDATA[elementor_header_footer]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_edit_mode</wp:meta_key>
			<wp:meta_value><![CDATA[builder]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_template_type</wp:meta_key>
			<wp:meta_value><![CDATA[wp-page]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_version</wp:meta_key>
			<wp:meta_value><![CDATA[3.19.0]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_data</wp:meta_key>
			<wp:meta_value><![CDATA[$homeJson]]></wp:meta_value>
		</wp:postmeta>
	</item>

	<!-- PAGE 2: ABOUT US -->
	<item>
		<title>About Us</title>
		<link>https://digitalexperts.io/about/</link>
		<pubDate>Mon, 02 Nov 2026 06:00:00 +0000</pubDate>
		<dc:creator><![CDATA[admin]]></dc:creator>
		<guid isPermaLink="false">https://digitalexperts.io/?page_id=20</guid>
		<description></description>
		<content:encoded><![CDATA[]]></content:encoded>
		<wp:post_id>20</wp:post_id>
		<wp:post_date>2026-11-02 06:00:00</wp:post_date>
		<wp:post_name>about</wp:post_name>
		<wp:status>publish</wp:status>
		<wp:post_type>page</wp:post_type>
		<wp:postmeta>
			<wp:meta_key>_wp_page_template</wp:meta_key>
			<wp:meta_value><![CDATA[elementor_header_footer]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_edit_mode</wp:meta_key>
			<wp:meta_value><![CDATA[builder]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_template_type</wp:meta_key>
			<wp:meta_value><![CDATA[wp-page]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_data</wp:meta_key>
			<wp:meta_value><![CDATA[$aboutJson]]></wp:meta_value>
		</wp:postmeta>
	</item>

	<!-- PAGE 3: SERVICES -->
	<item>
		<title>Services</title>
		<link>https://digitalexperts.io/services/</link>
		<pubDate>Mon, 02 Nov 2026 06:00:00 +0000</pubDate>
		<dc:creator><![CDATA[admin]]></dc:creator>
		<guid isPermaLink="false">https://digitalexperts.io/?page_id=30</guid>
		<wp:post_id>30</wp:post_id>
		<wp:post_name>services</wp:post_name>
		<wp:status>publish</wp:status>
		<wp:post_type>page</wp:post_type>
		<wp:postmeta>
			<wp:meta_key>_wp_page_template</wp:meta_key>
			<wp:meta_value><![CDATA[elementor_header_footer]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_edit_mode</wp:meta_key>
			<wp:meta_value><![CDATA[builder]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_template_type</wp:meta_key>
			<wp:meta_value><![CDATA[wp-page]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_data</wp:meta_key>
			<wp:meta_value><![CDATA[$servicesJson]]></wp:meta_value>
		</wp:postmeta>
	</item>

	<!-- PAGE 4: OUR PARTNERS -->
	<item>
		<title>Our Partners</title>
		<link>https://digitalexperts.io/partners/</link>
		<pubDate>Mon, 02 Nov 2026 06:00:00 +0000</pubDate>
		<dc:creator><![CDATA[admin]]></dc:creator>
		<guid isPermaLink="false">https://digitalexperts.io/?page_id=40</guid>
		<wp:post_id>40</wp:post_id>
		<wp:post_name>partners</wp:post_name>
		<wp:status>publish</wp:status>
		<wp:post_type>page</wp:post_type>
		<wp:postmeta>
			<wp:meta_key>_wp_page_template</wp:meta_key>
			<wp:meta_value><![CDATA[elementor_header_footer]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_edit_mode</wp:meta_key>
			<wp:meta_value><![CDATA[builder]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_template_type</wp:meta_key>
			<wp:meta_value><![CDATA[wp-page]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_data</wp:meta_key>
			<wp:meta_value><![CDATA[$partnersJson]]></wp:meta_value>
		</wp:postmeta>
	</item>

	<!-- PAGE 5: CONTACT US -->
	<item>
		<title>Contact Us</title>
		<link>https://digitalexperts.io/contact/</link>
		<pubDate>Mon, 02 Nov 2026 06:00:00 +0000</pubDate>
		<dc:creator><![CDATA[admin]]></dc:creator>
		<guid isPermaLink="false">https://digitalexperts.io/?page_id=50</guid>
		<wp:post_id>50</wp:post_id>
		<wp:post_name>contact</wp:post_name>
		<wp:status>publish</wp:status>
		<wp:post_type>page</wp:post_type>
		<wp:postmeta>
			<wp:meta_key>_wp_page_template</wp:meta_key>
			<wp:meta_value><![CDATA[elementor_header_footer]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_edit_mode</wp:meta_key>
			<wp:meta_value><![CDATA[builder]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_template_type</wp:meta_key>
			<wp:meta_value><![CDATA[wp-page]]></wp:meta_value>
		</wp:postmeta>
		<wp:postmeta>
			<wp:meta_key>_elementor_data</wp:meta_key>
			<wp:meta_value><![CDATA[$contactJson]]></wp:meta_value>
		</wp:postmeta>
	</item>
</channel>
</rss>
"@

[System.IO.File]::WriteAllText('C:\Users\user\.gemini\antigravity\scratch\digital-experts\wordpress\import\digital-experts-wxr-export.xml', $wxr)
Write-Host "Generated WXR Export successfully! Length: " $wxr.Length
